function [ dydt ] = trajectory( t,y,params )

% Current Conditions 
IC_m = y(1:4);
IC_sc = y(5:8);

% Specify variables to initial conditions

% Moon %%%%%%%
x_m = IC_m(1);
y_m = IC_m(2);
u_m = IC_m(3);
v_m = IC_m(4);
% Spacecraft %%%%%%%
x_sc = IC_sc(1);
y_sc = IC_sc(2);
u_sc = IC_sc(3);
v_sc = IC_sc(4);

% Current distances b/n bodies
d_em = sqrt((0 - x_m)^2 + (0 - y_m)^2);
d_es = sqrt((0 - x_sc)^2 + (0 - y_sc)^2);
d_ms = sqrt((x_m - x_sc)^2 + (y_m - y_sc)^2);

% Parameters of spacecraft trajectory [SI units]
G = params(1); % Gravitational constant
r_e = params(2); % radius of earth
r_m = params(3); % radius of moon
m_e = params(4); % mass of earth
m_m = params(5); % mass of moon
m_sc = params(6); % mass of spacecraft

% Define forces
Fes_x = (G * m_e * m_sc * ( 0 - x_sc))/(d_es^3);
Fes_y = (G * m_e * m_sc * ( 0 - y_sc))/(d_es^3) ;
Fms_x = (G * m_m * m_sc * ( x_m - x_sc))/(d_ms^3);
Fms_y = (G * m_m * m_sc * ( y_m - y_sc))/(d_ms^3);
Fem_x = (G * m_e * m_m * ( 0 - x_m))/(d_em^3);
Fem_y = (G * m_e * m_m * ( 0 - y_m))/(d_em^3);
Fse_x = -Fes_x;
Fse_y = -Fes_y;
Fsm_x = -Fms_x;
Fsm_y = -Fms_y;
Fme_x = -Fem_x;
Fme_y = -Fem_y;

% Acceleration of spacecraft
as_x = (Fms_x + Fes_x) / m_sc;
as_y = (Fms_y + Fes_y) / m_sc;

% Acceleration of moon
am_x = (Fem_x + Fsm_x) / m_m;
am_y = (Fem_y + Fsm_y) / m_m;




dydt = [u_m; v_m; am_x; am_y;
    u_sc; v_sc; as_x; as_y];

end

