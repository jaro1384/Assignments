function [ value, isterminal, direction ] = crash( t,y )
value = 1;

r_e = 6.371e6; % radius of earth [m]
r_m = 1.7371e6; % [m]

x_m = y(1);
y_m = y(2);
x_sc = y(5);
y_sc = y(6);


d_em = sqrt((x_m)^2 + (y_m)^2);
d_es = sqrt((x_sc)^2 + (y_sc)^2);
d_ms = sqrt((x_m - x_sc)^2 + (y_m - y_sc)^2);


value1 = d_ms - r_m;
value2 = d_es - r_e;
value3 = d_es - 2*d_em;
value = [value1, value2, value3];

isterminal = [1,1,1];
 
direction = [-1, -1, 1];


end

