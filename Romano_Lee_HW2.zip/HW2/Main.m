clc, clear, close all;
profile on
% Kent Lee & Jaquelyn Romano
% Assignment 2

% Given Information/Initial Conditions
IC = [];
G = 6.674*10^-11; % N(m/kg)^2;
% Distances
dES = 3.4e8; % Earth-Spacecraft
dEM = 3.84403e8; % Earth-moon

% Earth %%%%%%%%%%%%%%%%%%%%%%%%%%
m_e = 5.97219e24; % kg
r_e = 6.371e6; % m
IC_e = [0 0 0 0]; % Initial state of the earth

% Moon %%%%%%%%%%%%%%%%%%%%%%%%%%%
m_m = 7.34767309e22; % kg
r_m = 1.7371e6; % m
theta_m = 42.5; % degrees
V_m = sqrt((G * m_e^2)/((m_e + m_m)*dEM)); % m/s
X_m = dEM*cosd(theta_m); 
Y_m = dEM*sind(theta_m); 
u_m = -V_m*sind(theta_m); 
v_m = V_m*cosd(theta_m); 
IC_m = [X_m Y_m u_m v_m]; % Initial state of the moon

% Spacecraft %%%%%%%%%%%%%%%%%%%%% 
m_sc = 28833; % kg
theta_sc = 50; % degrees
% initial 1000
V_sc = 1000; % m/s
X_sc = dES * cosd(theta_sc);
Y_sc = dES * sind(theta_sc);
u_sc = V_sc * cosd(theta_sc);
v_sc = V_sc * sind(theta_sc);
IC_sc = [X_sc Y_sc u_sc v_sc]; % Initial state of the spacecraft

% Parameters for trajectory function
params = [G, r_e, r_m, m_e, m_m, m_sc];

% Time span of interest
time = [0 1e6];

% Initial Conditions Matrix
IC = [ IC_m IC_sc];

% opts = odeset('Events', @crash, 'Reltol', 1e-8);
% [t,y] = ode45( @(t,y) trajectory(t,y,params), time, IC, opts);

% [t, y, te, ye, ie] = optimiz(IC, params);

% v0 is initial guess, starting point for optimization

v0 = [0, 50];

v = fminsearch(@(v)optimiz(v,IC, params), v0);
% 
% figure(1)
% plot([0 0], [0 0], 'go')
% hold on
% plot(y(:,1), y(:,2), 'r.')
% plot(y(:,5), y(:,6), 'b.')
% legend('Earth', 'moon', 'spacecraft', 'Location', 'best')
profile viewer