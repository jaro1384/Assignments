function f = optimiz(v, IC, params)
% 

u_sc_i = IC(:,7);
v_sc_i = IC(:,8);

% add to initial velocity of s/c
IC(:,7) = u_sc_i + v(1);
IC(:,8) = v_sc_i + v(2);

% Set simulation options
opts = odeset('Events', @crash, 'Reltol', 1e-8);
time = [0 1e6];

% Fly!
[t, y, te, ye, ie] = ode45( @(t,y) trajectory(t,y,params), time, IC, opts);

% d_es = sqrt((ye(5))^2 - (ye(6))^2);
% set other velocities for value1 and value3 very high so not minimum 
dv = sqrt(ye(5)^2 + ye(6)^2);

if ie == 1 | ie == 3
    dv = 1e6;
end

f = dv;
end