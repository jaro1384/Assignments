function [m, b] = leastsquares(x, y)
% Least squares method
% outputs; 

N = length(x);
A = sum(x);
B = sum(y);
c = x.*y;
d = x.*x;
C = sum(c);
D = sum(d);
m = (A*B - N*C)/(A^2 - N*D);
b = (A*C - B*D)/(A^2 - N*D);
end

