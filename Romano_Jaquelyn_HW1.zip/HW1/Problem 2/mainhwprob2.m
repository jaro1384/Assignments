clc; clear all; close all;
% angles of attack
x = [-5 -2 0 2 3 5 7 10 14];
% coefficients of lift
y = [-0.008 -0.003 0.001 0.005 0.007 0.006 0.009 0.017 0.019];
[m,b] = leastsquares(x,y);

y2 = m.*x + b;

plot(x ,y, '*', x, y2)
title('Wind Tunnel Data')
xlabel('Angle of Attack in degrees')
ylabel('Coefficient of Lift')
legend('Data', 'Best-Fit', 'Location', 'northwest')