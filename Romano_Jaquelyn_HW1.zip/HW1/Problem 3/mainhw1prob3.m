% ASEN 4057 HW 1
% Jaquelyn Romano
% January 30, 2017
% Problem 3

clc; clear all; close all;
% radius of balloon meters
r_ball = 3;
% weight of payload kg
w_pay = 5;
% weight of empty balloon kg
w_bempty = 0.6;
% molecular weight helium
mw = 4.02;
% maximum altitude of balloon
maxh = calcmaxh(r_ball, w_pay, w_bempty, mw);
display = 'Question 3.d The maximum altitude of the balloon is %0.2f meters';
fprintf(display, maxh);
