function [ T,P ] = temppress( h )
% Temppress computes temperature and pressure of balloon at a given
% altitude 
% Inputs: h altitude meters
% Outputs: T Temperature P pressure
if h <= 11,000;
    T = 15.04 - 0.00649*h;
    P = 101.29*((T + 273.1)/288.08)^5.256;
elseif h <=25000;
    T = -56.46;
    P = 22.65*exp(1.73 - 0.000157*h);
else
    T = -131.21 + 0.00299*h;
    P = 2.488*((T + 273.1)/216.6)^-11.388;
end
end

