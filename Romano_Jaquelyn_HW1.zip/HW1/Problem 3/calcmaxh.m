function [ maxh ] = calcmaxh( r_ball, w_pay, w_bempty, mw )
% calcmaxh calculates maximum altitude of balloon 
% Inputs: r_ball radius of balloon, w_pay weight of payload, w_bempty
% weight of empty balloon, mw is molecular weight
% Outputs: maxh maximum altitude of balloon 

h = 0; 
% weight of displaced air 
w_air = calcairw(r_ball, h);
% total weight of balloon
w_ball = calcballw(r_ball, w_pay, w_bempty, mw);
% max altitude reached right before weight of balloon equals weight of displaced
% air
while w_ball < w_air
    w_air = calcairw(r_ball, h);
    h = h + 10;
end
maxh = max(h);
end

