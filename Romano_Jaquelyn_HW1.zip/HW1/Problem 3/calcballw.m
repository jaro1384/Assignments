function [ w_ball ] = calcballw( r_ball, w_pay, w_bempty, mw )
% calcballw calculates the total weight of the balloon 
% Inputs: r_ball radius of balloon, w_pay weight of payload, w_bempty
% empty weight of balloon, mw molecular weight of gas
% Outputs: w_ball total weight of balloon

% density of air at sea level
rho = 1.225;
% weight of gas in balloon
w_gas = ((4*pi*rho*r_ball^3)/3)*(mw/28.966);
% total weight of balloon
w_ball = w_gas + w_pay + w_bempty;

end

