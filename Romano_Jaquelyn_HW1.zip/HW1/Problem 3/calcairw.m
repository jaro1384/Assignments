function [ w_air ] = calcairw( r_ball, h )
% calcairw calculates weight of displaced air
% Inputs: r_ball radius of balloon, h altitude of balloon
% Outputs: w_air weight of displaced air

% Temperature and pressure at input altitude
[T, P] = temppress (h);
% density of air at input altitude
rho = P / (0.2869*(T+273.1));
% weight of displaced air
w_air = (4*pi*rho*r_ball^3)/3;

end

