

clc; clear all; close all;
% Request user input for initial velocity and angle
promptV = 'What is the initial velocity in meters per second?';
promptTheta = 'What is the initial angle in degrees?';
V = input(promptV);
Theta = input(promptTheta);

% Find displacements in x and y direction
[x ,y] = displacement(V, Theta);
plotProblem1(x,y)
