function [x, y] = displacement(V, Theta)

g = -9.81; % m/s
% Find termination time, y = 0
tf = -V*sind(Theta)/(0.5*g); % seconds
%create t arrays
t = linspace(0, tf);

% solve for x, y

x = V*cosd(Theta).*t;
y = 0.5*g*t.^2 + V*sind(Theta)*t;