function varargout = assn3(varargin)
% ASSN3 MATLAB code for assn3.fig
%      ASSN3, by itself, creates a new ASSN3 or raises the existing
%      singleton*.
%
%      H = ASSN3 returns the handle to a new ASSN3 or the handle to
%      the existing singleton*.
%
%      ASSN3('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ASSN3.M with the given input arguments.
%
%      ASSN3('Property','Value',...) creates a new ASSN3 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before assn3_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to assn3_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help assn3

% Last Modified by GUIDE v2.5 17-Feb-2017 21:26:36

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @assn3_OpeningFcn, ...
                   'gui_OutputFcn',  @assn3_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before assn3 is made visible.
function assn3_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to assn3 (see VARARGIN)

% create the data to plot

% Choose default command line output for assn3
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes assn3 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = assn3_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in start.
function start_Callback(hObject, eventdata, handles)
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
corrplot;


function milavg_Callback(hObject, eventdata, handles)
% hObject    handle to milavg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of milavg as text
%        str2double(get(hObject,'String')) returns contents of milavg as a double
txtmilavg=str2double(get(hObject,'String'));
handles.milavg=txtmilavg;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function milavg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to milavg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function SampFreq_Callback(hObject, eventdata, handles)
% hObject    handle to SampFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SampFreq as text
%        str2double(get(hObject,'String')) returns contents of SampFreq as a double
txtSampFreq=str2double(get(hObject,'String'));
handles.SampFreq=txtSampFreq;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function SampFreq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SampFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function intfreq_Callback(hObject, eventdata, handles)
% hObject    handle to intfreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of intfreq as text
%        str2double(get(hObject,'String')) returns contents of intfreq as a double
txtintFreq=str2double(get(hObject,'String'));
handles.intFreq=txtintFreq;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function intfreq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to intfreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function mildata_Callback(hObject, eventdata, handles)
% hObject    handle to mildata (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of mildata as text
%        str2double(get(hObject,'String')) returns contents of mildata as a double
txtmildata=str2double(get(hObject,'String'));
handles.mildata=txtmildata;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function mildata_CreateFcn(hObject, eventdata, handles)
% hObject    handle to mildata (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.

function anim_CreateFcn(hObject, eventdata, handles)
% hObject    handle to anim (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function ampdat_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ampdat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function freqdat_CreateFcn(hObject, eventdata, handles)
% hObject    handle to freqdat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function Gpsnum_Callback(hObject, eventdata, handles)
% hObject    handle to gpsnum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gpsnum as text
%        str2double(get(hObject,'String')) returns contents of gpsnum as a double
txtGpsnum=str2double(get(hObject,'String'));
handles.Gpsnum=txtGpsnum;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function Gpsnum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gpsnum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in startprocess.
function startprocess_Callback(hObject, eventdata, handles)
% hObject    handle to startprocess (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[e_i,e_q,p_i,p_q,l_i,l_q,carrierfq,codefq]=findandtrack(handles.Gpsnum,handles.mildata,handles.SampFreq,handles.intfreq);
handles.findandtrack(:,1)=e_i;
handles.findandtrack(:,2)=e_q;
handles.findandtrack(:,3)=p_i;
handles.findandtrack(:,4)=p_q;
handles.findandtrack(:,5)=l_i;
handles.findandtrack(:,6)=l_q;
handles.findandtrack(:,7)=carrierfq;
handles.findandtrack(:,8)=codefq;
plotresults;
set(handles.goAhead,'Enable','on','BackgroundColor','green')



