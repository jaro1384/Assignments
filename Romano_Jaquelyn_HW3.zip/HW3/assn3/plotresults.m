%Simple script to plot the results of the bistatic processing of the
%direct channel;  create two figures and plot important aspects

amphandle = handles.ampdata;
freqhandle = handles.freqdata;
e_i = handles.findandtrack(:,1);
e_q = handles.findandtrack(:,2);
p_i = handles.findandtrack(:,3); 
p_q = handles.findandtrack(:,4);
l_i = handles.findandtrack(:,5);
l_q = handles.findandtrack(:,6);
carrierfq = handles.findandtrack(:,7);
codefq  =handles.findandtrack(:,8);



% figure(901)
subplot(2,1,1, 'Parent', amphandle),plot(p_i .^2 + p_q .^ 2, 'g.-')
hold on
grid
subplot(2,1,1, 'Parent', amphandle),plot(e_i .^2 + e_q .^ 2, 'bx-')
subplot(2,1,1, 'Parent', amphandle),plot(l_i .^2 + l_q .^ 2, 'r+-')
hold off
xlabel('milliseconds')
ylabel('amplitude')
title('Correlation Results')
legend('prompt','early','late')
subplot(2,2,3, 'Parent', amphandle),plot(p_i)
grid
xlabel('milliseconds')
ylabel('amplitude')
title('Prompt I Channel')
subplot(2,2,4, 'Parent', amphandle),plot(p_q)
grid
xlabel('milliseconds')
ylabel('amplitude')
title('Prompt Q Channel')

% figure(902)
subplot(2,1,1, 'Parent', freqhandle),plot(1.023e6 - codefq)
grid
xlabel('milliseconds')
ylabel('Hz')
title('Tracked Code Frequency (Deviation from 1.023MHz)')
subplot(2,1,2, 'Parent', freqhandle),plot(carrierfq)
grid
xlabel('milliseconds')
ylabel('Hz')
title('Tracked Intermediate Frequency')
